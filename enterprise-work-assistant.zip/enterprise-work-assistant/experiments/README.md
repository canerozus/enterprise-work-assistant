# Experiments

One folder per experiment. Each folder contains:

- `README.md` with **Hypothesis**, **Setup**, **Results** and **Takeaways**
- `docker-compose.yml` for the services involved
- load test scripts (k6), failure injection config (Toxiproxy) and any dashboards used

Experiments are deliberately small and isolated. Once a pattern is validated here, it moves into `apps/`.
