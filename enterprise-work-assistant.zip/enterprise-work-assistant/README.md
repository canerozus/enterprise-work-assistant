# Enterprise Work Assistant

A Glean-style assistant that connects to company tools (GitHub, Slack, Jira, Google Drive), indexes their content with permission awareness, answers questions with hybrid search + RAG, and can take actions (open a ticket, draft a message).

This is also a learning project. Every feature is built, stressed, measured and documented: the goal is to be able to explain why the system is designed the way it is, when it breaks, and how to fix it.

## Stack

FastAPI · PostgreSQL · Redis · OpenSearch · pgvector · SQS / Kafka · Docker · Kubernetes · Terraform · GitHub Actions · OpenTelemetry · Prometheus · Grafana

## Repository layout

| Path | Purpose |
| --- | --- |
| `apps/` | Application code (API, workers) |
| `packages/` | Shared libraries |
| `infrastructure/` | Docker Compose and Terraform |
| `experiments/` | Isolated experiments that test one concept at a time |
| `docs/architecture/` | Architecture diagrams, before/after for each phase |
| `docs/adr/` | Architecture Decision Records |

## Learning loop

Learn → design → build → break it on purpose → measure → write it down.

Each experiment in `experiments/` states a hypothesis, how it was tested, and what actually happened. Each significant design choice gets an ADR in `docs/adr/`.
