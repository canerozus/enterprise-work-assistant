# ADR-0000: Title

- Date:
- Status: Proposed | Accepted | Superseded by ADR-XXXX

## Context

## Decision

## Alternatives considered

## Consequences
